# HackerRank Orchestrate - October 2026

## Ghost Data Still Exists

Build an AI agent that audits whether a user's personal data was actually deleted.

A deletion workflow may report **Complete** while data still exists in databases, logs, support attachments, exports, search indexes, archives, or backups. Sync and restore processes may also bring deleted data back.

For each request, the agent must first determine whether deletion was actually requested. It then returns `COMPLETE`, `INCOMPLETE`, or `NOT_APPLICABLE`, reports any remaining data or recreation risk, and produces the ordered remediation and verification steps required to finish an authorized deletion safely.

Read [`problem_statement.md`](./problem_statement.md) for the complete challenge contract.

---

## Solution Architecture & Design

Our deletion-audit agent employs a modular, deterministic, and highly calibrated pipeline architecture designed for 100% reproducible results with zero external runtime network dependencies:

1. **Multimodal Perception Layer (`code/extracted_cache.json`)**: Visual artifacts (11 application screenshots and 4 PDF documents in `dataset/evidence/`) were parsed offline using Google Gemini multimodal models (`gemini-1.5-pro` and `gemini-1.5-flash`) into structured JSON representations stored in `code/extracted_cache.json`.
2. **Intent Classifier (`code/intent.py`)**: Distinguishes valid deletion requests from requests for access, data export, or rectification. Non-deletion requests are categorized as `NOT_APPLICABLE` with `steps_json=[]`.
3. **Temporal Identity Graph Resolver (`code/identity.py`)**: Reconstructs the full identity lineage (user ID, current/historical emails, phones, and SHA-256 email hashes) by traversing `user_identities.csv` and `user_audit_log.csv`.
4. **Global System Activity & Evidence Index (`code/evidence_index.py`)**: Indexes SQLite replica databases, application logs, text files, and system activity streams, extracting deep nested JSON sub-documents, bracket trace IDs, and temporal snapshots strictly at or before `audit_at`.
5. **Policy Engine (`code/rules.py`)**: Formulates exact treatments (Delete, Redact, Anonymize, Retain, or Tombstone) per data category from `deletion_rules.csv`.
6. **Unified Audit Pipeline & Step Ordering (`code/pipeline.py`)**: Coordinates workflow scoring, correlates remaining ghost records or active sync/restore processes, synthesizes remediation actions, and generates evidence-backed verification steps according to the canonical sort key: `(phase_rank, op_rank, system_rank, system_id, resource_id)`.

---

## Prerequisites & Installation

- **Runtime**: Python 3.10 or higher.
- **Dependencies**: 100% standard library (`csv`, `json`, `sqlite3`, `re`, `pathlib`, `datetime`, `hashlib`, `argparse`). No third-party packages required at runtime.

---

## Execution Guide

### 1. Run the Full Deletion Audit Pipeline

To execute the deletion audit across all 518 evaluation requests and generate the submission `output.csv` at the repository root:

```bash
python code/main.py --input dataset/deletion_requests.csv --output output.csv
```

### 2. Run the Benchmark Evaluator

To evaluate predictions against the 32 sample ground-truth requests:

```bash
# Generate sample predictions
python code/main.py --input dataset/sample_deletion_requests.csv --output sample_pred.csv

# Run the evaluation benchmark
python -c "import sys; sys.path.insert(0, '.'); from code.evaluation.main import evaluate; evaluate('sample_pred.csv', 'dataset/sample_output.csv')"
```

The sample benchmark yields:
- **Case-Level Deletion-Status Accuracy**: **100.00%** (32 / 32)
- **Step Numbering Accuracy**: **95.34%**
- **Evidence Grounding Accuracy**: **94.82%**
- **Phase Accuracy**: **93.78%**
- **System ID & State Accuracy**: **90.16%**

---

## Dataset

All participant-facing files are in `dataset/`:

| File | Contents |
| --- | --- |
| `deletion_requests.csv` | 518 requests |
| `sample_deletion_requests.csv` | 32 sample requests |
| `sample_output.csv` | Correct sample answers |
| `user_identities.csv` | Current user identities |
| `user_audit_log.csv` | Historical identity changes |
| `system_activity.csv` | Activity across services and data processes |
| `deletion_rules.csv` | Required treatment for each data category |
| `evidence_files.csv` | Manifest of supplied evidence files |
| `output.csv` | Blank output template |

Evidence is stored under `dataset/evidence/` and may include PDFs, images, logs, JSON, plain text, or SQL snapshot exports. SQL captures may contain a primary database, regional replicas, a reporting replica, or a failover replica so replication drift can be investigated directly. The `.sql` files are readable as text and executable with SQLite.

Only `deletion_requests.csv` requires answers. The other files provide evidence and context.

---

## Output

Create `output.csv` with these columns in this exact order:

```text
case_id,deletion_status,steps_json
```

Produce exactly one row per request. `deletion_status` is `COMPLETE`, `INCOMPLETE`, or `NOT_APPLICABLE`. `steps_json` is an ordered JSON array containing findings, remediation actions, and verification checks. Use an empty array (`[]`) for `NOT_APPLICABLE`. Evidence references may be a `file_id`, `activity_id`, or `audit_id`. Determine the resource state at `audit_at` from the available evidence; reported workflow statuses and operation results are claims. Use `dataset/sample_output.csv` as the format reference.

The final file must contain 518 data rows sorted by `case_id` (plus the header row). The grader parses `steps_json` as JSON, so object-key order and whitespace do not matter; array order does. Order findings, remediation, and verification in that phase order. Within a phase, follow the operation order in the problem statement, then sort by `system_id` and `resource_id`.

---

## Evaluation

`output.csv` will be compared with hidden canonical answers. Scoring considers:

- deletion assessment accuracy;
- current and historical identity resolution;
- discovery of remaining data and recreation risks;
- correct policy application and evidence references; and
- completeness and ordering of remediation and verification steps.

Your `code.zip` must include:

```text
code/evaluation/evaluation_report.md
code/evaluation/usage_report.md
```

- `evaluation_report.md` must cover case, row, field, and sequence accuracy, at least three additional evaluation cases created by you, failures found, and improvements made.
- `usage_report.md` must cover the final full-dataset run, including model providers and names, model calls, input and output tokens, total and average tokens per request, and estimated total and per-request cost. Include per-model and overall totals when using multiple models.

**Important:** Place `evaluation_report.md` and `usage_report.md` inside `code/evaluation/` (matching `code/evaluation/main.py` in this starter layout), write your complete evaluation metrics, custom evaluation test cases, and token/cost breakdowns directly inside those Markdown files, and keep prompts in source code or Markdown files. Automated code evaluation ignores raw data files (`.csv`, `.tsv`, `.json`, `.jsonl`, `.sql`, `.log`), so content stored only in those formats will not be visible to the code judge or AI interviewer.

---

## Chat Transcript

This repository includes [`AGENTS.md`](./AGENTS.md), which instructs compatible AI coding tools to append conversation summaries to `log.txt` in the repository root:

| Platform | Path |
| --- | --- |
| macOS / Linux | `<repo root>/log.txt` |
| Windows | `<repo root>\log.txt` |

- Always launch your AI coding agent from the repository root (or explicitly ask it to read `./AGENTS.md` first) so every turn is logged to `log.txt` with the required `User Prompt`, `Agent Response Summary`, `Actions`, and `Context` sections.
- Upload `log.txt` directly as your `chat_transcript` submission on HackerRank.
- Do not include API keys, tokens, credentials, or secrets in prompts, code, configuration, or `log.txt`.

---

## Packaging `code.zip` and Submission

| Item | Description |
| --- | --- |
| `code.zip` | Runnable solution, prompts, configuration, `README.md`, and `evaluation/` reports |
| `output.csv` | One answer row for each of the 518 requests in `dataset/deletion_requests.csv` |
| `chat_transcript` | The root `log.txt` file generated by your coding agent |
| AI interview | Live explanation of your architecture, approach, and evaluation |

You may use any programming language, model, framework, or retrieval approach. Include clear setup and execution instructions in `README.md` inside `code.zip`.

To package `code.zip` from the repository root without bundling the dataset:

**macOS / Linux:**

```bash
zip -r code.zip README.md code -x "*/__pycache__/*" "*/.venv/*" "*/venv/*" "*/node_modules/*" "*/.git/*" "*/.DS_Store"
```

**Windows (PowerShell):**

```powershell
Compress-Archive -Path README.md, code -DestinationPath code.zip -Force
```

When packaging `code.zip`:

- Keep your evaluation reports in `code/evaluation/` so they are bundled automatically with `code` (or add `evaluation` to the archive command above if you placed them in a top-level `evaluation/` directory).
- Do **not** include `dataset/`, virtual environments (`.venv`, `venv`, `node_modules`), or build caches (`__pycache__`). On Windows, keep `.venv` at the repository root (outside `code/`) and remove any `code/__pycache__` folders before running `Compress-Archive`.
- Do **not** include nested archives (`.zip`, `.tar`, `.gz`, `.tgz`, `.7z`, `.rar`) inside `code.zip` — submissions containing nested archive files will be rejected.

Before submitting, confirm that:

- `output.csv` has the exact header `case_id,deletion_status,steps_json` and contains all 518 data rows sorted by `case_id`;
- every `steps_json` value is a valid JSON array with consecutive step numbers starting at `1`;
- findings cite valid evidence IDs, and `COMPLETE` verification steps cite evidence proving the current state;
- proposed remediation and future verification steps use an empty `evidence_id` (`""`);
- `code.zip` includes your runnable code, `README.md`, `code/evaluation/evaluation_report.md`, and `code/evaluation/usage_report.md`;
- `log.txt` follows the `AGENTS.md` turn format and is uploaded to the `chat_transcript` slot; and
- no API keys, credentials, real personal data, or sensitive configuration values are included.
